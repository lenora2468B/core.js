---
name: "🧚‍♂️ Feature Request"
about: "Wouldn’t it be nice if 💭"
labels: feature
---

<!-- Please replace all placeholders such as this below -->

**What’s missing?**

<!-- Describe your feature idea  -->

**Why?**

<!-- Describe the problem you are facing -->

**Alternatives you tried**

<!-- Describe the workarounds you tried so far and how they worked for you -->
